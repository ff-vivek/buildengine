import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:buildbeacon/data/models/build_models_simple.dart';
import 'package:buildbeacon/theme.dart';
import 'package:buildbeacon/utils/constants.dart';
import 'package:buildbeacon/utils/validators.dart';

class SourceSelectionStep extends StatefulWidget {
  final GlobalKey<FormState> formKey;
  final SourceType selectedSourceType;
  final File? selectedFile;
  final String uploadProgress;
  final String ffUrl;
  final String ffToken;
  final String gitUrl;
  final String branch;
  final ValueChanged<SourceType> onSourceTypeChanged;
  final ValueChanged<File?> onFileSelected;
  final void Function(Uint8List bytes, String name)? onMemoryFileSelected;
  final ValueChanged<String> onFFUrlChanged;
  final ValueChanged<String> onFFTokenChanged;
  final ValueChanged<String> onGitUrlChanged;
  final ValueChanged<String> onBranchChanged;

  const SourceSelectionStep({
    super.key,
    required this.formKey,
    required this.selectedSourceType,
    required this.selectedFile,
    required this.uploadProgress,
    required this.ffUrl,
    required this.ffToken,
    required this.gitUrl,
    required this.branch,
    required this.onSourceTypeChanged,
    required this.onFileSelected,
    this.onMemoryFileSelected,
    required this.onFFUrlChanged,
    required this.onFFTokenChanged,
    required this.onGitUrlChanged,
    required this.onBranchChanged,
  });

  @override
  State<SourceSelectionStep> createState() => _SourceSelectionStepState();
}

class _SourceSelectionStepState extends State<SourceSelectionStep>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // In-memory selection (web)
  String? _memoryName;
  int? _memorySize;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: AppConstants.enableGitRepoSource ? 3 : 2,
      vsync: this,
      initialIndex: _getTabIndex(widget.selectedSourceType),
    );
    _tabController.addListener(_onTabChanged);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  int _getTabIndex(SourceType type) {
    switch (type) {
      case SourceType.uploadZip:
        return 0;
      case SourceType.flutterFlow:
        return 1;
      case SourceType.gitRepo:
        return AppConstants.enableGitRepoSource ? 2 : 0;
    }
  }

  void _onTabChanged() {
    final sourceTypes = [
      SourceType.uploadZip,
      SourceType.flutterFlow,
      if (AppConstants.enableGitRepoSource) SourceType.gitRepo,
    ];

    if (_tabController.index < sourceTypes.length) {
      widget.onSourceTypeChanged(sourceTypes[_tabController.index]);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: widget.formKey,
      child: Column(
        children: [
          _buildHeader(context),
          _buildTabBar(context),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildUploadTab(),
                _buildFlutterFlowTab(),
                if (AppConstants.enableGitRepoSource) _buildGitTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Choose Your Source',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            'Select how you want to provide your Flutter project.',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: LightModeColors.lightNeutral600,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      decoration: BoxDecoration(
        color: LightModeColors.lightNeutral100,
        borderRadius: BorderRadius.circular(12),
      ),
           child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: LightModeColors.lightPrimary,
          borderRadius: BorderRadius.circular(8),
        ),
        labelColor: Colors.white,
        unselectedLabelColor: LightModeColors.lightNeutral600,
        labelStyle: const TextStyle(fontWeight: FontWeight.w600),
        dividerColor: Colors.transparent,
        tabs: [
          const Padding(padding: EdgeInsets.all(16.0), child: Tab(text: 'Upload ZIP')),
          const Tab(text: 'FlutterFlow'),
          if (AppConstants.enableGitRepoSource) const Tab(text: 'Git Repo'),
        ],
      ),
    );
  }

  Widget _buildUploadTab() {
    final showMemoryInfo = _memoryName != null && _memorySize != null;

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Upload Project ZIP'),
          const SizedBox(height: 16),
          _buildUploadArea(),
          if (widget.selectedFile != null || showMemoryInfo) ...[
            const SizedBox(height: 16),
            if (widget.selectedFile != null)
              _buildFileInfoCard(
                name: widget.selectedFile!.path.split('/').last,
                size: _safeFileSize(widget.selectedFile),
                onClear: () {
                  widget.onFileSelected(null);
                },
              )
            else if (showMemoryInfo)
              _buildFileInfoCard(
                name: _memoryName!,
                size: _memorySize!,
                onClear: () {
                  setState(() {
                    _memoryName = null;
                    _memorySize = null;
                  });
                },
              ),
          ],
          if (widget.uploadProgress.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text(
              widget.uploadProgress,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: LightModeColors.lightPrimary,
                  ),
            ),
          ],
        ],
      ),
    );
  }

  int _safeFileSize(File? file) {
    try {
      if (file == null) return 0;
      return file.lengthSync();
    } catch (_) {
      return 0;
    }
  }

  Widget _buildFlutterFlowTab() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('FlutterFlow Project'),
          const SizedBox(height: 16),
          TextFormField(
            initialValue: widget.ffUrl,
            decoration: const InputDecoration(
              labelText: 'Project URL',
              hintText: 'https://app.flutterflow.io/project/...',
              prefixIcon: Icon(Icons.link),
            ),
            validator: Validators.validateFlutterFlowUrl,
            onChanged: widget.onFFUrlChanged,
          ),
          const SizedBox(height: 16),
          TextFormField(
            initialValue: widget.ffToken,
            decoration: const InputDecoration(
              labelText: 'Access Token',
              hintText: 'Your FlutterFlow access token',
              prefixIcon: Icon(Icons.key),
            ),
            obscureText: true,
            validator: Validators.validateToken,
            onChanged: widget.onFFTokenChanged,
          ),
          const SizedBox(height: 16),
          _buildBranchField(),
          const SizedBox(height: 16),
          _buildWarningCard(
            'Your access token will be used only for this build and won\'t be stored permanently.',
          ),
        ],
      ),
    );
  }

  Widget _buildGitTab() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Git Repository'),
          const SizedBox(height: 16),
          TextFormField(
            initialValue: widget.gitUrl,
            decoration: const InputDecoration(
              labelText: 'Git URL',
              hintText: 'https://github.com/user/repo.git',
              prefixIcon: Icon(Icons.account_tree),
            ),
            validator: Validators.validateGitUrl,
            onChanged: widget.onGitUrlChanged,
          ),
          const SizedBox(height: 16),
          _buildBranchField(),
          const SizedBox(height: 16),
          _buildWarningCard(
            'Public repositories only. Private repos require authentication setup.',
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
    );
  }

  Widget _buildUploadArea() {
    return GestureDetector(
      onTap: _selectFile,
      child: Container(
        width: double.infinity,
        height: 200,
        decoration: BoxDecoration(
          border: Border.all(
            color: LightModeColors.lightNeutral300,
            width: 2,
            style: BorderStyle.solid,
          ),
          borderRadius: BorderRadius.circular(12),
          color: LightModeColors.lightNeutral50,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.cloud_upload_outlined,
              size: 48,
              color: LightModeColors.lightNeutral400,
            ),
            const SizedBox(height: 16),
            Text(
              'Tap to select ZIP file',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: LightModeColors.lightNeutral600,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              'Max file size: ${Validators.formatFileSize(AppConstants.maxFileSize)}',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: LightModeColors.lightNeutral500,
                  ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFileInfoCard({required String name, required int size, required VoidCallback onClear}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: LightModeColors.lightPrimaryContainer,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(
            Icons.folder_zip,
            color: LightModeColors.lightPrimary,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                Text(
                  Validators.formatFileSize(size),
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: LightModeColors.lightNeutral600,
                      ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: onClear,
            color: LightModeColors.lightNeutral500,
          ),
        ],
      ),
    );
  }

  Widget _buildBranchField() {
    return TextFormField(
      initialValue: widget.branch,
      decoration: const InputDecoration(
        labelText: 'Branch',
        hintText: 'main',
        prefixIcon: Icon(Icons.account_tree_outlined),
      ),
      validator: Validators.validateBranch,
      onChanged: widget.onBranchChanged,
    );
  }

  Widget _buildWarningCard(String message) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: LightModeColors.lightNeutral100,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: LightModeColors.lightNeutral200),
      ),
      child: Row(
        children: [
          Icon(
            Icons.info_outline,
            color: LightModeColors.lightNeutral500,
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              message,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: LightModeColors.lightNeutral600,
                  ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _selectFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['zip'],
      allowMultiple: false,
    );

    if (result != null) {
      final platformFile = result.files.single;
      final name = platformFile.name;
      final data = platformFile.bytes; // May be null on non-web platforms
      final path = platformFile.path; // May be null on web

      // Debug prints
      // ignore: avoid_print
      print('selectedFile Name: $name');
      // ignore: avoid_print
      print('selectedFile Path: $path');
      // ignore: avoid_print
      print('selectedFile HasBytes: ${data != null}');

      File? file;
      if (path != null) {
        file = File(path);
      }

      // Basic validation using name/bytes where possible
      String? error;

      // Extension check
      final extension = name.toLowerCase().split('.').last;
      if (!AppConstants.allowedFileExtensions.contains('.$extension')) {
        error = AppConstants.invalidFileType;
      }

      // Size check
      if (error == null) {
        final size = data?.length ?? (file?.lengthSync() ?? 0);
        if (size <= 0) {
          error = AppConstants.invalidFileType;
        } else if (size > AppConstants.maxFileSize) {
          error = AppConstants.fileTooLarge;
        }
      }

      // Deep validation: ZIP magic header (PK..)
      if (error == null) {
        try {
          List<int> header;
          if (data != null && data.length >= 4) {
            header = data.sublist(0, 4);
          } else if (file != null) {
            final raf = await file.open();
            header = await raf.read(4);
            await raf.close();
          } else {
            header = const <int>[];
          }

          final isZipMagic = header.length >= 4 &&
              header[0] == 0x50 && // 'P'
              header[1] == 0x4B && // 'K'
              (
                // local file header       PK\x03\x04
                (header[2] == 0x03 && header[3] == 0x04) ||
                // empty archive           PK\x05\x06
                (header[2] == 0x05 && header[3] == 0x06) ||
                // spanned/split archive   PK\x07\x08
                (header[2] == 0x07 && header[3] == 0x08)
              );

          if (!isZipMagic) {
            error = AppConstants.invalidFileType; // Reuse existing message
          }
        } catch (_) {
          // If we can't read the file header, treat as invalid
          error = AppConstants.invalidFileType;
        }
      }

      if (!mounted) return;

      if (error == null) {
        if (file != null) {
          widget.onFileSelected(file);
          setState(() {
            _memoryName = null;
            _memorySize = null;
          });
        } else if (data != null) {
          // Store memory selection for UI, and propagate up if callback provided
          setState(() {
            _memoryName = name;
            _memorySize = data.length;
          });
          widget.onMemoryFileSelected?.call(data, name);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Selected: $name (${Validators.formatFileSize(data.length)})'),
              backgroundColor: LightModeColors.lightTertiary,
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(error),
            backgroundColor: LightModeColors.lightError,
          ),
        );
      }
    }
  }
}
